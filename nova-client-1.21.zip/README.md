# NOVA CLIENT
Minecraft Java 1.21 icin Fabric istemci modu. Right Shift ile mavi-siyah menu acilir.
Derleme: GitHub Actions sekmesi > son calisma > Artifacts > nova-client-jar.
