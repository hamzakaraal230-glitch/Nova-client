package com.nova.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {

    public static class CpsModule extends Module {
        private final ArrayDeque<Long> clicks = new ArrayDeque<>();
        private boolean wasDown;

        public CpsModule() {
            super("CPS Counter", "Saniyedeki tiklama sayisi", Category.PVP);
        }

        @Override
        public void onTick(MinecraftClient client) {
            boolean down = client.currentScreen == null
                    && GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            if (down && !wasDown) clicks.addLast(System.currentTimeMillis());
            wasDown = down;
            prune();
        }

        private void prune() {
            long limit = System.currentTimeMillis() - 1000L;
            while (!clicks.isEmpty() && clicks.peekFirst() < limit) clicks.pollFirst();
        }

        public int getCps() {
            prune();
            return clicks.size();
        }
    }

    public static final Module FULLBRIGHT = new Module("Fullbright", "Karanlikta gorus", Category.RENDER) {
        @Override
        public void onTick(MinecraftClient client) {
            ClientPlayerEntity p = client.player;
            if (p == null) return;
            StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 240) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
            }
        }

        @Override
        protected void onDisable() {
            ClientPlayerEntity p = MinecraftClient.getInstance().player;
            if (p != null) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    };

    public static final Module HUD = new Module("Info HUD", "FPS ve koordinatlar", Category.RENDER) {
        { setEnabled(true); }
    };

    public static final CpsModule CPS = new CpsModule();

    public static final Module KEYSTROKES = new Module("Keystrokes", "W A S D tus gosterimi", Category.PVP);

    public static final Module SPRINT = new Module("Auto Sprint", "Ileri giderken otomatik kosar", Category.MOVEMENT) {
        @Override
        public void onTick(MinecraftClient client) {
            ClientPlayerEntity p = client.player;
            if (p == null) return;
            if (p.input.movementForward > 0 && !p.isSneaking() && !p.horizontalCollision) {
                p.setSprinting(true);
            }
        }
    };

    private static final List<Module> MODULES = List.of(HUD, FULLBRIGHT, CPS, KEYSTROKES, SPRINT);

    private ModuleManager() {}

    public static List<Module> all() {
        return MODULES;
    }

    public static List<Module> of(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) {
            if (m.category == category) out.add(m);
        }
        return out;
    }

    public static void tick(MinecraftClient client) {
        for (Module m : MODULES) {
            if (m.isEnabled()) m.onTick(client);
        }
    }
}
