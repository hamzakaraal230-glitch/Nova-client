package com.nova.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class NovaClient implements ClientModInitializer {
    public static final String MOD_ID = "novaclient";
    public static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.novaclient.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "key.categories.novaclient"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new NovaScreen());
                }
            }
            ModuleManager.tick(client);
        });

        HudRenderCallback.EVENT.register((context, tickCounter) -> renderHud(context));
    }

    private static void renderHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        int y = 4;
        if (ModuleManager.HUD.isEnabled()) {
            ctx.drawTextWithShadow(mc.textRenderer, "NOVA CLIENT", 4, y, 0xFF5CA8FF);
            ctx.drawTextWithShadow(mc.textRenderer, "FPS: " + mc.getCurrentFps(), 4, y + 11, 0xFFFFFFFF);
            ctx.drawTextWithShadow(mc.textRenderer,
                    String.format("XYZ: %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()),
                    4, y + 22, 0xFFFFFFFF);
            y += 36;
        }
        if (ModuleManager.CPS.isEnabled()) {
            ctx.drawTextWithShadow(mc.textRenderer, "CPS: " + ModuleManager.CPS.getCps(), 4, y, 0xFFFFFFFF);
            y += 14;
        }
        if (ModuleManager.KEYSTROKES.isEnabled()) {
            key(ctx, mc, "W", 24, y, mc.options.forwardKey.isPressed());
            key(ctx, mc, "A", 4, y + 20, mc.options.leftKey.isPressed());
            key(ctx, mc, "S", 24, y + 20, mc.options.backKey.isPressed());
            key(ctx, mc, "D", 44, y + 20, mc.options.rightKey.isPressed());
        }
    }

    private static void key(DrawContext ctx, MinecraftClient mc, String label, int x, int y, boolean down) {
        ctx.fill(x, y, x + 18, y + 18, down ? 0xC02E7BFF : 0x90000000);
        ctx.drawCenteredTextWithShadow(mc.textRenderer, label, x + 9, y + 5, 0xFFFFFFFF);
    }
}
