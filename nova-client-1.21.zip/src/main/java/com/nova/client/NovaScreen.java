package com.nova.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class NovaScreen extends Screen {
    private static final int SIDE_W = 92;
    private static final int HEADER_H = 34;
    private static final int FOOTER_H = 20;
    private static final int ROW_H = 30;
    private static final int TAB_H = 28;

    private static final int COL_DIM_TOP = 0xC0010308;
    private static final int COL_DIM_BOTTOM = 0xD0061226;
    private static final int COL_BORDER = 0xFF2E7BFF;
    private static final int COL_PANEL = 0xF00A0F1C;
    private static final int COL_SIDE = 0xFF070C18;
    private static final int COL_HEADER = 0xFF0D1830;
    private static final int COL_TITLE = 0xFF5CA8FF;
    private static final int COL_ROW_OFF = 0xFF111A2E;
    private static final int COL_ROW_OFF_HOVER = 0xFF1A2742;
    private static final int COL_ROW_ON = 0xFF123F8F;
    private static final int COL_ROW_ON_HOVER = 0xFF1A55BD;
    private static final int COL_DESC = 0xFF8FA8CC;
    private static final int COL_ACCENT = 0xFF4DA3FF;

    private static Category selected = Category.RENDER;

    public NovaScreen() {
        super(Text.literal("NOVA CLIENT"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int panelW() { return Math.min(380, this.width - 12); }

    private int bodyRows() {
        int max = Category.values().length;
        for (Category c : Category.values()) max = Math.max(max, ModuleManager.of(c).size());
        return max;
    }

    private int panelH() { return HEADER_H + bodyRows() * ROW_H + FOOTER_H + 8; }

    private int panelX() { return (this.width - panelW()) / 2; }

    private int panelY() { return Math.max(4, (this.height - panelH()) / 2); }

    private boolean inTab(double mx, double my, int x, int ty) {
        return mx >= x + 6 && mx < x + SIDE_W - 4 && my >= ty && my < ty + TAB_H - 4;
    }

    private boolean inRow(double mx, double my, int x, int ry) {
        return mx >= x + SIDE_W + 8 && mx < x + panelW() - 8 && my >= ry && my < ry + ROW_H - 5;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fillGradient(0, 0, this.width, this.height, COL_DIM_TOP, COL_DIM_BOTTOM);

        int x = panelX(), y = panelY(), w = panelW(), h = panelH();

        ctx.fill(x - 2, y - 2, x + w + 2, y + h + 2, 0x402E7BFF);
        ctx.fill(x - 1, y - 1, x + w + 1, y + h + 1, COL_BORDER);
        ctx.fill(x, y, x + w, y + h, COL_PANEL);

        // baslik
        ctx.fillGradient(x, y, x + w, y + HEADER_H, COL_HEADER, COL_PANEL);
        ctx.fill(x, y, x + w, y + 2, COL_ACCENT);
        ctx.drawCenteredTextWithShadow(this.textRenderer, "N O V A   C L I E N T", x + w / 2, y + 13, COL_TITLE);

        // sol kategori kutulari
        ctx.fill(x, y + HEADER_H, x + SIDE_W, y + h, COL_SIDE);
        ctx.fill(x + SIDE_W, y + HEADER_H, x + SIDE_W + 1, y + h, 0x602E7BFF);
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int ty = y + HEADER_H + 8 + i * TAB_H;
            boolean sel = cats[i] == selected;
            boolean hover = inTab(mouseX, mouseY, x, ty);
            int bg = sel ? COL_ROW_ON : (hover ? COL_ROW_OFF_HOVER : COL_ROW_OFF);
            ctx.fill(x + 6, ty, x + SIDE_W - 4, ty + TAB_H - 4, bg);
            if (sel) ctx.fill(x + 6, ty, x + 9, ty + TAB_H - 4, COL_ACCENT);
            ctx.drawCenteredTextWithShadow(this.textRenderer, cats[i].label,
                    x + SIDE_W / 2 + 2, ty + (TAB_H - 4 - 8) / 2, sel ? 0xFFFFFFFF : 0xFFB0C4E8);
        }

        // modul listesi
        List<Module> mods = ModuleManager.of(selected);
        int cx1 = x + SIDE_W + 8, cx2 = x + w - 8;
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            int ry = y + HEADER_H + 8 + i * ROW_H;
            boolean hover = inRow(mouseX, mouseY, x, ry);
            boolean on = m.isEnabled();
            int bg = on ? (hover ? COL_ROW_ON_HOVER : COL_ROW_ON) : (hover ? COL_ROW_OFF_HOVER : COL_ROW_OFF);

            ctx.fill(cx1, ry, cx2, ry + ROW_H - 5, bg);
            ctx.fill(cx1, ry, cx1 + 3, ry + ROW_H - 5, on ? COL_ACCENT : 0xFF24324F);
            ctx.drawTextWithShadow(this.textRenderer, m.name, cx1 + 10, ry + 5, 0xFFFFFFFF);
            ctx.drawTextWithShadow(this.textRenderer, m.description, cx1 + 10, ry + 15, COL_DESC);

            int sx = cx2 - 8 - 28;
            int sy = ry + (ROW_H - 5) / 2 - 6;
            ctx.fill(sx, sy, sx + 28, sy + 12, on ? COL_ACCENT : 0xFF2A3550);
            int kx = on ? sx + 28 - 11 : sx + 2;
            ctx.fill(kx, sy + 2, kx + 9, sy + 10, 0xFFFFFFFF);
        }

        ctx.drawCenteredTextWithShadow(this.textRenderer, "Right Shift / ESC: kapat",
                x + SIDE_W + (w - SIDE_W) / 2, y + h - 14, 0xFF6C7FA3);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int x = panelX(), y = panelY();
            Category[] cats = Category.values();
            for (int i = 0; i < cats.length; i++) {
                if (inTab(mouseX, mouseY, x, y + HEADER_H + 8 + i * TAB_H)) {
                    selected = cats[i];
                    return true;
                }
            }
            List<Module> mods = ModuleManager.of(selected);
            for (int i = 0; i < mods.size(); i++) {
                if (inRow(mouseX, mouseY, x, y + HEADER_H + 8 + i * ROW_H)) {
                    mods.get(i).toggle();
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
