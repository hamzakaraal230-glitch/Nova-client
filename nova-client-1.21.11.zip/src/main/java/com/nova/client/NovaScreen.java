package com.nova.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class NovaScreen extends Screen {
    private enum Tab {
        MODULES("Modules"), FAVORITES("Favorites"), APPEARANCE("Appearance");
        final String label;
        Tab(String label) { this.label = label; }
    }

    private static final int SIDE_W = 96;
    private static final int HEADER_H = 30;
    private static final int FOOTER_H = 16;
    private static final int CARD_H = 44;
    private static final int ROW = 48;
    private static final int SET_H = 26;
    private static final int SET_ROW = 30;

    private static final int COL_DARK = 0xFF080B1A;
    private static final int COL_BORDER = 0xFF2A3560;
    private static final int COL_DIVIDER = 0xFF1B2347;
    private static final int COL_SOFT = 0xFF121A38;
    private static final int COL_CARD_OFF = 0xFF10162E;
    private static final int COL_CARD_OFF_HOVER = 0xFF18214A;
    private static final int COL_MUTED = 0xFF8A97C2;
    private static final int COL_TEXT = 0xFFFFFFFF;

    private static Tab tab = Tab.MODULES;
    private static Category section = null; // null = Overview
    private Module configuring = null;
    private int scroll = 0;

    public NovaScreen() {
        super(Component.literal("CHICKEN CLIENT"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ---------- Geometri ----------
    private int pw() { return Math.min(430, this.width - 8); }
    private int ph() { return Math.min(280, this.height - 8); }
    private int px() { return (this.width - pw()) / 2; }
    private int py() { return (this.height - ph()) / 2; }

    private int listTop() { return py() + HEADER_H + 36; }
    private int listBottom() { return py() + ph() - FOOTER_H - 6; }
    private int visibleRows() { return Math.max(1, (listBottom() - listTop()) / ROW); }
    private int cardX1() { return px() + SIDE_W + 8; }
    private int cardX2() { return px() + pw() - 8 - 14; }

    private int tabX1(int index) {
        int x = px() + SIDE_W + 8;
        Tab[] t = Tab.values();
        for (int i = 0; i < index; i++) x += this.font.width(t[i].label) + 22;
        return x;
    }

    private int tabX2(int index) {
        return tabX1(index) + this.font.width(Tab.values()[index].label) + 16;
    }

    private boolean in(double mx, double my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }

    private List<Module> currentModules() {
        List<Module> out = new ArrayList<>();
        for (Module m : ModuleManager.all()) {
            if (tab == Tab.FAVORITES) {
                if (m.favorite) out.add(m);
            } else if (section == null || m.category == section) {
                out.add(m);
            }
        }
        return out;
    }

    private void clampScroll(int size) {
        int max = Math.max(0, size - visibleRows());
        if (scroll > max) scroll = max;
        if (scroll < 0) scroll = 0;
    }

    private String title() {
        if (configuring != null) return configuring.name + " settings";
        if (tab == Tab.FAVORITES) return "Favorites";
        if (tab == Tab.APPEARANCE) return "Appearance";
        if (section == null) return "All modules";
        return switch (section) {
            case RENDER -> "Visual modules";
            case PVP -> "PvP modules";
            case MOVEMENT -> "Movement modules";
        };
    }

    private String subtitle() {
        if (configuring != null) return "Tune how this module works.";
        if (tab == Tab.FAVORITES) return "Modules you starred.";
        if (tab == Tab.APPEARANCE) return "Pick your colors.";
        if (section == null) return "Everything in one place.";
        return switch (section) {
            case RENDER -> "A clearer view of your world.";
            case PVP -> "Handy info for fights.";
            case MOVEMENT -> "Get around easier.";
        };
    }

    private void gradLine(GuiGraphics g, int x1, int x2, int y, int h, int c1, int c2) {
        int n = Math.max(1, (x2 - x1) / 4);
        for (int i = 0; i < n; i++) {
            int sx1 = x1 + i * (x2 - x1) / n;
            int sx2 = x1 + (i + 1) * (x2 - x1) / n;
            g.fill(sx1, y, sx2, y + h, Theme.blend(c1, c2, (float) i / n));
        }
    }

    // ---------- Cizim ----------
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        int accent = Theme.accent(), accent2 = Theme.accent2();
        g.fillGradient(0, 0, this.width, this.height,
                Theme.blend(0xFF02030A, accent, 0.10f) & 0xB0FFFFFF | 0xB0000000,
                Theme.blend(0xFF05061A, accent2, 0.16f) & 0xC0FFFFFF | 0xC0000000);

        int x = px(), y = py(), w = pw(), h = ph();
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, Theme.blend(COL_BORDER, accent, 0.45f));
        g.fillGradient(x, y, x + w, y + h, 0xF00B1030, 0xF0140B30);

        // Baslik
        g.fillGradient(x, y, x + w, y + HEADER_H, Theme.blend(COL_DARK, accent, 0.30f), 0x00000000);
        g.fill(x + 10, y + 7, x + 26, y + 23, accent);
        g.fill(x + 14, y + 11, x + 22, y + 19, accent2);
        g.fill(x + 17, y + 14, x + 19, y + 16, COL_DARK);
        g.drawString(this.font, "CHICKEN", x + 32, y + 11, COL_TEXT);

        Tab[] tabs = Tab.values();
        for (int i = 0; i < tabs.length; i++) {
            boolean sel = tabs[i] == tab;
            int x1 = tabX1(i), x2 = tabX2(i);
            if (sel) {
                g.fill(x1, y + 5, x2, y + 25, Theme.blend(COL_DARK, accent, 0.40f));
                g.fill(x1, y + 24, x2, y + 25, accent2);
            }
            g.drawString(this.font, tabs[i].label, x1 + 8, y + 11, sel ? COL_TEXT : COL_MUTED);
        }
        g.drawString(this.font, "X", x + w - 18, y + 11, 0xFFFF6B81);
        gradLine(g, x, x + w, y + HEADER_H, 2, accent, accent2);

        // Sol menu
        g.drawString(this.font, "MENU", x + 12, y + HEADER_H + 9, accent2);
        String[] names = {"Overview", "Render", "PvP", "Movement"};
        Category[] cats = {null, Category.RENDER, Category.PVP, Category.MOVEMENT};
        for (int i = 0; i < names.length; i++) {
            int iy = y + HEADER_H + 24 + i * 24;
            boolean sel = tab == Tab.MODULES && cats[i] == section;
            boolean hover = in(mouseX, mouseY, x + 6, iy, x + SIDE_W - 6, iy + 20);
            int barColor = cats[i] == null ? accent : Theme.catColor(cats[i]);
            if (sel) {
                g.fill(x + 6, iy, x + SIDE_W - 6, iy + 20, Theme.blend(COL_DARK, barColor, 0.28f));
                g.fill(x + 6, iy + 2, x + 9, iy + 18, barColor);
            } else if (hover) {
                g.fill(x + 6, iy, x + SIDE_W - 6, iy + 20, COL_SOFT);
            }
            g.fill(x + 14, iy + 7, x + 20, iy + 13, barColor);
            g.drawString(this.font, names[i], x + 26, iy + 6, sel ? COL_TEXT : 0xFFC5CFEE);
        }
        g.drawString(this.font, "CHICKEN", x + 12, y + h - FOOTER_H - 36, accent);
        g.drawString(this.font, "Fabric 1.21.11", x + 12, y + h - FOOTER_H - 25, COL_TEXT);
        g.drawString(this.font, ModuleManager.activeCount() + " / " + ModuleManager.all().size() + " active",
                x + 12, y + h - FOOTER_H - 14, accent2);
        g.fill(x + SIDE_W, y + HEADER_H + 2, x + SIDE_W + 1, y + h - FOOTER_H, COL_DIVIDER);

        // Icerik basligi
        g.drawString(this.font, title(), cardX1(), y + HEADER_H + 9, COL_TEXT);
        g.drawString(this.font, subtitle(), cardX1(), y + HEADER_H + 21, COL_MUTED);

        if (configuring != null) {
            renderSettings(g, mouseX, mouseY);
        } else if (tab == Tab.APPEARANCE) {
            renderAppearance(g);
        } else {
            renderModules(g, mouseX, mouseY);
        }

        // Alt cubuk
        gradLine(g, x + 8, x + w - 8, y + h - FOOTER_H, 1, accent, accent2);
        g.fill(x + 12, y + h - 9, x + 16, y + h - 5, 0xFF3DDC97);
        g.drawString(this.font, "Changes save automatically", x + 22, y + h - 11, 0xFFC5CFEE);
        String close = "ESC  Close";
        g.drawString(this.font, close, x + w - 10 - this.font.width(close), y + h - 11, COL_MUTED);
    }

    private void renderModules(GuiGraphics g, int mouseX, int mouseY) {
        List<Module> mods = currentModules();
        clampScroll(mods.size());
        int accent = Theme.accent(), accent2 = Theme.accent2();
        int x1 = cardX1(), x2 = cardX2();
        int rows = visibleRows();

        if (mods.isEmpty()) {
            g.drawString(this.font, "Burada modül yok.", x1, listTop() + 6, COL_MUTED);
        }

        for (int i = 0; i < rows; i++) {
            int idx = scroll + i;
            if (idx >= mods.size()) break;
            Module m = mods.get(idx);
            int ry = listTop() + i * ROW;
            boolean hover = in(mouseX, mouseY, x1, ry, x2, ry + CARD_H);
            boolean on = m.isEnabled();
            int cat = Theme.catColor(m.category);

            if (on) {
                int top = Theme.blend(COL_DARK, accent, hover ? 0.66f : 0.55f);
                int bottom = Theme.blend(COL_DARK, accent2, hover ? 0.50f : 0.40f);
                g.fillGradient(x1, ry, x2, ry + CARD_H, top, bottom);
                g.fill(x1, ry, x2, ry + 1, accent2);
            } else {
                g.fill(x1, ry, x2, ry + CARD_H, hover ? COL_CARD_OFF_HOVER : COL_CARD_OFF);
            }

            // ikon kutusu
            g.fill(x1 + 6, ry + 8, x1 + 32, ry + 34, on ? cat : Theme.blend(COL_DARK, cat, 0.35f));
            g.drawCenteredString(this.font, m.name.substring(0, 1), x1 + 19, ry + 17, COL_TEXT);

            g.drawString(this.font, m.name, x1 + 40, ry + 7, COL_TEXT);
            g.drawString(this.font, m.description, x1 + 40, ry + 19, on ? 0xFFD8E2FF : COL_MUTED);
            if (m.hasSettings()) {
                g.drawString(this.font, "Configure >", x1 + 40, ry + 31, on ? COL_TEXT : accent2);
            }

            // favori yildizi
            int sx = x2 - 8 - 28;
            g.drawString(this.font, m.favorite ? "\u2605" : "\u2606", sx - 20, ry + 17,
                    m.favorite ? 0xFFFFD25C : COL_MUTED);

            // anahtar
            int sy = ry + (CARD_H - 12) / 2;
            g.fill(sx, sy, sx + 28, sy + 12, on ? 0xFF3DDC97 : 0xFF2A3560);
            int kx = on ? sx + 28 - 11 : sx + 2;
            g.fill(kx, sy + 2, kx + 9, sy + 10, 0xFFFFFFFF);
        }

        // kaydirma oklari
        int ax1 = x2 + 3, ax2 = x2 + 13;
        g.fill(ax1, listTop(), ax2, listTop() + 14, COL_SOFT);
        g.drawCenteredString(this.font, "^", ax1 + 5, listTop() + 3, accent2);
        g.fill(ax1, listBottom() - 14, ax2, listBottom(), COL_SOFT);
        g.drawCenteredString(this.font, "v", ax1 + 5, listBottom() - 11, accent2);
    }

    // --- ayar satiri geometri ---
    private int setRowY(int i) { return listTop() + i * SET_ROW; }
    private int plusX1() { return cardX2() - 8 - 18; }
    private int minusX1() { return plusX1() - 52; }
    private int backX1() { return cardX2() - 44; }
    private int backY1() { return py() + HEADER_H + 8; }

    private void renderSettings(GuiGraphics g, int mouseX, int mouseY) {
        int accent = Theme.accent(), accent2 = Theme.accent2();
        int x1 = cardX1(), x2 = cardX2();

        boolean backHover = in(mouseX, mouseY, backX1(), backY1(), backX1() + 44, backY1() + 14);
        g.fill(backX1(), backY1(), backX1() + 44, backY1() + 14, backHover ? Theme.blend(COL_DARK, accent, 0.5f) : COL_SOFT);
        g.drawCenteredString(this.font, "< Back", backX1() + 22, backY1() + 3, COL_TEXT);

        List<Setting> list = configuring.settings;
        for (int i = 0; i < list.size(); i++) {
            Setting s = list.get(i);
            int ry = setRowY(i);
            boolean hover = in(mouseX, mouseY, x1, ry, x2, ry + SET_H);
            g.fill(x1, ry, x2, ry + SET_H, hover ? COL_CARD_OFF_HOVER : COL_CARD_OFF);
            g.fill(x1, ry, x1 + 3, ry + SET_H, accent2);
            g.drawString(this.font, s.name, x1 + 10, ry + 10, COL_TEXT);

            if (s.type == Setting.Type.BOOL) {
                int sx = x2 - 8 - 28;
                int sy = ry + (SET_H - 12) / 2;
                boolean on = s.asBool();
                g.fill(sx, sy, sx + 28, sy + 12, on ? 0xFF3DDC97 : 0xFF2A3560);
                int kx = on ? sx + 28 - 11 : sx + 2;
                g.fill(kx, sy + 2, kx + 9, sy + 10, 0xFFFFFFFF);
            } else {
                int by = ry + (SET_H - 18) / 2;
                g.fill(minusX1(), by, minusX1() + 18, by + 18, Theme.blend(COL_DARK, accent, 0.5f));
                g.drawCenteredString(this.font, "-", minusX1() + 9, by + 5, COL_TEXT);
                g.fill(plusX1(), by, plusX1() + 18, by + 18, Theme.blend(COL_DARK, accent, 0.5f));
                g.drawCenteredString(this.font, "+", plusX1() + 9, by + 5, COL_TEXT);
                g.drawCenteredString(this.font, s.display(), (minusX1() + 18 + plusX1()) / 2, ry + 10, accent2);
            }
        }
    }

    private void renderAppearance(GuiGraphics g) {
        int x1 = cardX1();
        int top = listTop() + 4;
        for (int i = 0; i < Theme.count(); i++) {
            int sx = x1 + i * 52;
            boolean sel = i == Theme.index();
            if (sel) g.fill(sx - 2, top - 2, sx + 42, top + 42, 0xFFFFFFFF);
            g.fillGradient(sx, top, sx + 40, top + 40, Theme.swatch(i), Theme.swatch2(i));
            g.drawCenteredString(this.font, Theme.NAMES[i], sx + 20, top + 48, sel ? COL_TEXT : COL_MUTED);
        }
    }

    // ---------- Girdi ----------
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            double mx = event.x(), my = event.y();
            int x = px(), y = py(), w = pw();

            if (in(mx, my, x + w - 26, y + 4, x + w - 4, y + 26)) {
                this.onClose();
                return true;
            }
            Tab[] tabs = Tab.values();
            for (int i = 0; i < tabs.length; i++) {
                if (in(mx, my, tabX1(i), y + 5, tabX2(i), y + 25)) {
                    tab = tabs[i];
                    configuring = null;
                    scroll = 0;
                    return true;
                }
            }
            Category[] cats = {null, Category.RENDER, Category.PVP, Category.MOVEMENT};
            for (int i = 0; i < cats.length; i++) {
                int iy = y + HEADER_H + 24 + i * 24;
                if (in(mx, my, x + 6, iy, x + SIDE_W - 6, iy + 20)) {
                    tab = Tab.MODULES;
                    section = cats[i];
                    configuring = null;
                    scroll = 0;
                    return true;
                }
            }

            if (configuring != null) {
                if (in(mx, my, backX1(), backY1(), backX1() + 44, backY1() + 14)) {
                    configuring = null;
                    return true;
                }
                List<Setting> list = configuring.settings;
                for (int i = 0; i < list.size(); i++) {
                    int ry = setRowY(i);
                    if (!in(mx, my, cardX1(), ry, cardX2(), ry + SET_H)) continue;
                    Setting s = list.get(i);
                    if (s.type == Setting.Type.BOOL) {
                        s.toggle();
                    } else if (in(mx, my, minusX1(), ry, minusX1() + 18, ry + SET_H)) {
                        s.dec();
                    } else if (in(mx, my, plusX1(), ry, plusX1() + 18, ry + SET_H)) {
                        s.inc();
                    }
                    Config.save();
                    return true;
                }
            } else if (tab == Tab.APPEARANCE) {
                int top = listTop() + 4;
                for (int i = 0; i < Theme.count(); i++) {
                    int sx = cardX1() + i * 52;
                    if (in(mx, my, sx, top, sx + 40, top + 40)) {
                        Theme.setIndex(i);
                        Config.save();
                        return true;
                    }
                }
            } else {
                List<Module> mods = currentModules();
                clampScroll(mods.size());
                int x1 = cardX1(), x2 = cardX2();

                int ax1 = x2 + 3, ax2 = x2 + 13;
                if (in(mx, my, ax1, listTop(), ax2, listTop() + 14)) { scroll--; clampScroll(mods.size()); return true; }
                if (in(mx, my, ax1, listBottom() - 14, ax2, listBottom())) { scroll++; clampScroll(mods.size()); return true; }

                for (int i = 0; i < visibleRows(); i++) {
                    int idx = scroll + i;
                    if (idx >= mods.size()) break;
                    int ry = listTop() + i * ROW;
                    if (!in(mx, my, x1, ry, x2, ry + CARD_H)) continue;
                    Module m = mods.get(idx);
                    int sx = x2 - 8 - 28;
                    if (m.hasSettings() && in(mx, my, x1 + 36, ry + 28, x1 + 110, ry + 42)) {
                        configuring = m;
                        return true;
                    }
                    if (mx >= sx - 26 && mx < sx - 4) {
                        m.favorite = !m.favorite;
                    } else {
                        m.toggle();
                    }
                    Config.save();
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (configuring == null && tab != Tab.APPEARANCE) {
            scroll -= (int) Math.signum(scrollY);
            clampScroll(currentModules().size());
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            this.onClose();
            return true;
        }
        return super.keyPressed(event);
    }
}
