package com.nova.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class NovaScreen extends Screen {
    private enum Tab {
        MODULES("Modules"), FAVORITES("Favorites"), APPEARANCE("Appearance");
        final String label;
        Tab(String label) { this.label = label; }
    }

    private static final int SIDE_W = 96;
    private static final int HEADER_H = 30;
    private static final int FOOTER_H = 16;
    private static final int CARD_H = 34;
    private static final int ROW = 38;

    private static final int COL_PANEL = 0xF0070B14;
    private static final int COL_BORDER = 0xFF1B2740;
    private static final int COL_DIVIDER = 0xFF141D31;
    private static final int COL_SOFT = 0xFF0E1626;
    private static final int COL_CARD_OFF = 0xFF0C1322;
    private static final int COL_CARD_OFF_HOVER = 0xFF131D33;
    private static final int COL_MUTED = 0xFF7F8CA8;
    private static final int COL_TEXT = 0xFFFFFFFF;

    private static Tab tab = Tab.MODULES;
    private static Category section = null; // null = Overview
    private int scroll = 0;

    public NovaScreen() {
        super(Component.literal("NOVA CLIENT"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ---------- Geometri ----------
    private int pw() { return Math.min(430, this.width - 8); }
    private int ph() { return Math.min(280, this.height - 8); }
    private int px() { return (this.width - pw()) / 2; }
    private int py() { return (this.height - ph()) / 2; }

    private int listTop() { return py() + HEADER_H + 36; }
    private int listBottom() { return py() + ph() - FOOTER_H - 6; }
    private int visibleRows() { return Math.max(1, (listBottom() - listTop()) / ROW); }
    private int cardX1() { return px() + SIDE_W + 8; }
    private int cardX2() { return px() + pw() - 8 - 14; }

    private int tabX1(int index) {
        int x = px() + SIDE_W + 8;
        Tab[] t = Tab.values();
        for (int i = 0; i < index; i++) x += this.font.width(t[i].label) + 22;
        return x;
    }

    private int tabX2(int index) {
        return tabX1(index) + this.font.width(Tab.values()[index].label) + 16;
    }

    private boolean in(double mx, double my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }

    private List<Module> currentModules() {
        List<Module> out = new ArrayList<>();
        for (Module m : ModuleManager.all()) {
            if (tab == Tab.FAVORITES) {
                if (m.favorite) out.add(m);
            } else if (section == null || m.category == section) {
                out.add(m);
            }
        }
        return out;
    }

    private void clampScroll(int size) {
        int max = Math.max(0, size - visibleRows());
        if (scroll > max) scroll = max;
        if (scroll < 0) scroll = 0;
    }

    private String title() {
        if (tab == Tab.FAVORITES) return "Favorites";
        if (tab == Tab.APPEARANCE) return "Appearance";
        if (section == null) return "All modules";
        return switch (section) {
            case RENDER -> "Visual modules";
            case PVP -> "PvP modules";
            case MOVEMENT -> "Movement modules";
        };
    }

    private String subtitle() {
        if (tab == Tab.FAVORITES) return "Modules you starred.";
        if (tab == Tab.APPEARANCE) return "Pick an accent color.";
        if (section == null) return "Everything in one place.";
        return switch (section) {
            case RENDER -> "A clearer view of your world.";
            case PVP -> "Handy info for fights.";
            case MOVEMENT -> "Get around easier.";
        };
    }

    // ---------- Cizim ----------
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        int accent = Theme.accent();
        g.fillGradient(0, 0, this.width, this.height, 0xB0030610, 0xC0070D1C);

        int x = px(), y = py(), w = pw(), h = ph();
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, COL_BORDER);
        g.fill(x, y, x + w, y + h, COL_PANEL);

        // Baslik
        g.fill(x + 10, y + 7, x + 26, y + 23, accent);
        g.fill(x + 15, y + 12, x + 21, y + 18, 0xFF070B14);
        g.drawString(this.font, "NOVA", x + 32, y + 11, COL_TEXT);

        Tab[] tabs = Tab.values();
        for (int i = 0; i < tabs.length; i++) {
            boolean sel = tabs[i] == tab;
            int x1 = tabX1(i), x2 = tabX2(i);
            if (sel) g.fill(x1, y + 5, x2, y + 25, COL_SOFT);
            g.drawString(this.font, tabs[i].label, x1 + 8, y + 11, sel ? COL_TEXT : COL_MUTED);
        }
        g.drawString(this.font, "X", x + w - 18, y + 11, COL_MUTED);
        g.fill(x, y + HEADER_H, x + w, y + HEADER_H + 1, COL_DIVIDER);

        // Sol menu
        g.drawString(this.font, "MENU", x + 12, y + HEADER_H + 9, COL_MUTED);
        String[] names = {"Overview", "Render", "PvP", "Movement"};
        Category[] cats = {null, Category.RENDER, Category.PVP, Category.MOVEMENT};
        for (int i = 0; i < names.length; i++) {
            int iy = y + HEADER_H + 24 + i * 24;
            boolean sel = tab == Tab.MODULES && cats[i] == section;
            boolean hover = in(mouseX, mouseY, x + 6, iy, x + SIDE_W - 6, iy + 20);
            if (sel) {
                g.fill(x + 6, iy, x + SIDE_W - 6, iy + 20, COL_SOFT);
                g.fill(x + 6, iy + 3, x + 9, iy + 17, accent);
            } else if (hover) {
                g.fill(x + 6, iy, x + SIDE_W - 6, iy + 20, 0xFF0A101D);
            }
            g.drawString(this.font, names[i], x + 16, iy + 6, sel ? COL_TEXT : 0xFFB5C0D8);
        }
        g.drawString(this.font, "NOVA CLIENT", x + 12, y + h - FOOTER_H - 36, COL_MUTED);
        g.drawString(this.font, "Fabric 1.21.11", x + 12, y + h - FOOTER_H - 25, COL_TEXT);
        g.drawString(this.font, ModuleManager.activeCount() + " / " + ModuleManager.all().size() + " active",
                x + 12, y + h - FOOTER_H - 14, COL_MUTED);
        g.fill(x + SIDE_W, y + HEADER_H + 1, x + SIDE_W + 1, y + h - FOOTER_H, COL_DIVIDER);

        // Icerik basligi
        g.drawString(this.font, title(), cardX1(), y + HEADER_H + 9, COL_TEXT);
        g.drawString(this.font, subtitle(), cardX1(), y + HEADER_H + 21, COL_MUTED);

        if (tab == Tab.APPEARANCE) {
            renderAppearance(g, mouseX, mouseY);
        } else {
            renderModules(g, mouseX, mouseY);
        }

        // Alt cubuk
        g.fill(x + 8, y + h - FOOTER_H, x + w - 8, y + h - FOOTER_H + 1, COL_DIVIDER);
        g.fill(x + 12, y + h - 9, x + 16, y + h - 5, 0xFF3DDC97);
        g.drawString(this.font, "Changes save automatically", x + 22, y + h - 11, 0xFFB5C0D8);
        String close = "ESC  Close";
        g.drawString(this.font, close, x + w - 10 - this.font.width(close), y + h - 11, COL_MUTED);
    }

    private void renderModules(GuiGraphics g, int mouseX, int mouseY) {
        List<Module> mods = currentModules();
        clampScroll(mods.size());
        int accent = Theme.accent();
        int x1 = cardX1(), x2 = cardX2();
        int rows = visibleRows();

        if (mods.isEmpty()) {
            g.drawString(this.font, "Burada modül yok.", x1, listTop() + 6, COL_MUTED);
        }

        for (int i = 0; i < rows; i++) {
            int idx = scroll + i;
            if (idx >= mods.size()) break;
            Module m = mods.get(idx);
            int ry = listTop() + i * ROW;
            boolean hover = in(mouseX, mouseY, x1, ry, x2, ry + CARD_H);
            boolean on = m.isEnabled();
            int bg = on ? (hover ? Theme.cardOnHover() : Theme.cardOn()) : (hover ? COL_CARD_OFF_HOVER : COL_CARD_OFF);
            g.fill(x1, ry, x2, ry + CARD_H, bg);

            // ikon kutusu
            g.fill(x1 + 6, ry + 6, x1 + 28, ry + 28, on ? Theme.iconBg() : COL_SOFT);
            g.drawCenteredString(this.font, m.name.substring(0, 1), x1 + 17, ry + 13, COL_TEXT);

            g.drawString(this.font, m.name, x1 + 36, ry + 7, COL_TEXT);
            g.drawString(this.font, m.description, x1 + 36, ry + 19, on ? 0xFFC5D3F0 : COL_MUTED);

            // favori yildizi
            int sx = x2 - 8 - 28;
            g.drawString(this.font, m.favorite ? "\u2605" : "\u2606", sx - 20, ry + 13, m.favorite ? 0xFFFFD25C : COL_MUTED);

            // anahtar
            int sy = ry + (CARD_H - 12) / 2;
            g.fill(sx, sy, sx + 28, sy + 12, on ? accent : 0xFF2A3550);
            int kx = on ? sx + 28 - 11 : sx + 2;
            g.fill(kx, sy + 2, kx + 9, sy + 10, 0xFFFFFFFF);
        }

        // kaydirma oklari
        int ax1 = x2 + 3, ax2 = x2 + 13;
        g.fill(ax1, listTop(), ax2, listTop() + 14, COL_SOFT);
        g.drawCenteredString(this.font, "^", ax1 + 5, listTop() + 3, COL_MUTED);
        g.fill(ax1, listBottom() - 14, ax2, listBottom(), COL_SOFT);
        g.drawCenteredString(this.font, "v", ax1 + 5, listBottom() - 11, COL_MUTED);
    }

    private void renderAppearance(GuiGraphics g, int mouseX, int mouseY) {
        int x1 = cardX1();
        int top = listTop() + 4;
        for (int i = 0; i < Theme.count(); i++) {
            int sx = x1 + i * 52;
            boolean sel = i == Theme.index();
            if (sel) g.fill(sx - 2, top - 2, sx + 42, top + 42, 0xFFFFFFFF);
            g.fill(sx, top, sx + 40, top + 40, Theme.swatch(i));
            g.drawCenteredString(this.font, Theme.NAMES[i], sx + 20, top + 48, sel ? COL_TEXT : COL_MUTED);
        }
    }

    // ---------- Girdi ----------
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) {
            double mx = event.x(), my = event.y();
            int x = px(), y = py(), w = pw();

            // kapat
            if (in(mx, my, x + w - 26, y + 4, x + w - 4, y + 26)) {
                this.onClose();
                return true;
            }
            // sekmeler
            Tab[] tabs = Tab.values();
            for (int i = 0; i < tabs.length; i++) {
                if (in(mx, my, tabX1(i), y + 5, tabX2(i), y + 25)) {
                    tab = tabs[i];
                    scroll = 0;
                    return true;
                }
            }
            // sol menu
            Category[] cats = {null, Category.RENDER, Category.PVP, Category.MOVEMENT};
            for (int i = 0; i < cats.length; i++) {
                int iy = y + HEADER_H + 24 + i * 24;
                if (in(mx, my, x + 6, iy, x + SIDE_W - 6, iy + 20)) {
                    tab = Tab.MODULES;
                    section = cats[i];
                    scroll = 0;
                    return true;
                }
            }

            if (tab == Tab.APPEARANCE) {
                int top = listTop() + 4;
                for (int i = 0; i < Theme.count(); i++) {
                    int sx = cardX1() + i * 52;
                    if (in(mx, my, sx, top, sx + 40, top + 40)) {
                        Theme.setIndex(i);
                        Config.save();
                        return true;
                    }
                }
            } else {
                List<Module> mods = currentModules();
                clampScroll(mods.size());
                int x1 = cardX1(), x2 = cardX2();

                // kaydirma oklari
                int ax1 = x2 + 3, ax2 = x2 + 13;
                if (in(mx, my, ax1, listTop(), ax2, listTop() + 14)) { scroll--; clampScroll(mods.size()); return true; }
                if (in(mx, my, ax1, listBottom() - 14, ax2, listBottom())) { scroll++; clampScroll(mods.size()); return true; }

                for (int i = 0; i < visibleRows(); i++) {
                    int idx = scroll + i;
                    if (idx >= mods.size()) break;
                    int ry = listTop() + i * ROW;
                    if (!in(mx, my, x1, ry, x2, ry + CARD_H)) continue;
                    Module m = mods.get(idx);
                    int sx = x2 - 8 - 28;
                    if (mx >= sx - 26 && mx < sx - 4) {
                        m.favorite = !m.favorite;
                    } else {
                        m.toggle();
                    }
                    Config.save();
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (tab != Tab.APPEARANCE) {
            scroll -= (int) Math.signum(scrollY);
            clampScroll(currentModules().size());
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            this.onClose();
            return true;
        }
        return super.keyPressed(event);
    }
}
