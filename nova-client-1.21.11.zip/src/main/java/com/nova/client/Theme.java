package com.nova.client;

public final class Theme {
    private static final int[] ACCENTS = {0xFF4D8DFF, 0xFF9B5CFF, 0xFF3DDC97, 0xFFFF5C7A};
    public static final String[] NAMES = {"Blue", "Purple", "Green", "Red"};
    private static int index = 0;

    private Theme() {}

    public static int count() { return ACCENTS.length; }
    public static int index() { return index; }
    public static void setIndex(int i) {
        if (i >= 0 && i < ACCENTS.length) index = i;
    }

    public static int swatch(int i) { return ACCENTS[i]; }
    public static int accent() { return ACCENTS[index]; }
    public static int cardOn() { return blend(0xFF0A0F1C, accent(), 0.38f); }
    public static int cardOnHover() { return blend(0xFF0A0F1C, accent(), 0.50f); }
    public static int iconBg() { return blend(0xFF0A0F1C, accent(), 0.55f); }

    public static int blend(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
