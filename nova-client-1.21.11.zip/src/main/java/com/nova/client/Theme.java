package com.nova.client;

public final class Theme {
    private static final int[] ACCENTS = {0xFF2F80FF, 0xFFA855FF, 0xFF22E58B, 0xFFFF3D5A};
    private static final int[] ACCENTS2 = {0xFF00D4FF, 0xFFFF4DD8, 0xFFB6F23A, 0xFFFFA01F};
    public static final String[] NAMES = {"Blue", "Purple", "Green", "Red"};
    private static int index = 0;

    private Theme() {}

    public static int count() { return ACCENTS.length; }
    public static int index() { return index; }
    public static void setIndex(int i) {
        if (i >= 0 && i < ACCENTS.length) index = i;
    }

    public static int swatch(int i) { return ACCENTS[i]; }
    public static int swatch2(int i) { return ACCENTS2[i]; }
    public static int accent() { return ACCENTS[index]; }
    public static int accent2() { return ACCENTS2[index]; }

    public static int catColor(Category c) {
        return switch (c) {
            case RENDER -> 0xFF22D3EE;
            case PVP -> 0xFFFF4D6D;
            case MOVEMENT -> 0xFF4ADE80;
        };
    }

    public static int blend(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
