package com.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/** Dunya koordinatini ekrana cevirip duvar arkasindan isaretleyen 2D ESP cizimi. */
public final class Overlay {
    private Overlay() {}

    private static void outline(GuiGraphics g, int x1, int y1, int x2, int y2, int c) {
        g.fill(x1, y1, x2, y1 + 1, c);
        g.fill(x1, y2 - 1, x2, y2, c);
        g.fill(x1, y1, x1 + 1, y2, c);
        g.fill(x2 - 1, y1, x2, y2, c);
    }

    public static void marker(GuiGraphics g, Minecraft mc, float partial,
                              double wx, double wy, double wz, String label, int color) {
        Entity p = mc.getCameraEntity();
        if (p == null) p = mc.player;
        if (p == null) return;

        double ex = Mth.lerp(partial, p.xo, p.getX());
        double ey = Mth.lerp(partial, p.yo, p.getY()) + p.getEyeHeight();
        double ez = Mth.lerp(partial, p.zo, p.getZ());
        double dx = wx - ex, dy = wy - ey, dz = wz - ez;

        double yaw = Math.toRadians(p.getViewYRot(partial));
        double pitch = Math.toRadians(p.getViewXRot(partial));
        double cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);

        double fx = -sy * cp, fy = -sp, fz = cy * cp;       // bakis yonu
        double rx = -cy, ry = 0, rz = -sy;                   // sag
        double ux = ry * fz - rz * fy;                       // yukari
        double uy = rz * fx - rx * fz;
        double uz = rx * fy - ry * fx;

        double depth = dx * fx + dy * fy + dz * fz;
        double px = dx * rx + dy * ry + dz * rz;
        double py = dx * ux + dy * uy + dz * uz;

        double t = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        int w = g.guiWidth(), h = g.guiHeight();
        double aspect = (double) w / h;

        boolean front = depth > 0.05;
        double nx, ny;
        if (front) {
            nx = px / (depth * t * aspect);
            ny = py / (depth * t);
        } else {
            nx = px;
            ny = -0.5;
        }

        boolean onScreen = front && Math.abs(nx) <= 0.95 && Math.abs(ny) <= 0.95;
        if (!onScreen) {
            double m = Math.max(Math.abs(nx), Math.abs(ny)) / 0.92;
            if (m < 1e-6) m = 1;
            nx /= m;
            ny /= m;
        }

        int sx = (int) (w / 2.0 + nx * w / 2.0);
        int sY = (int) (h / 2.0 - ny * h / 2.0);
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        String text = label + "  " + (int) dist + "m";
        int tw = mc.font.width(text);

        if (onScreen) {
            int half = (int) Mth.clamp((h / 2.0) / (t * depth) / 2.0, 5, 60);
            outline(g, sx - half, sY - half, sx + half, sY + half, color);
            outline(g, sx - half - 1, sY - half - 1, sx + half + 1, sY + half + 1, 0x80000000);
            int tx = sx - tw / 2;
            int ty = sY - half - 12;
            g.fill(tx - 2, ty - 1, tx + tw + 2, ty + 9, 0x90000000);
            g.drawString(mc.font, text, tx, ty, color);
        } else {
            g.fill(sx - 4, sY - 4, sx + 4, sY + 4, 0xA0000000);
            g.fill(sx - 3, sY - 3, sx + 3, sY + 3, color);
            int tx = (int) Mth.clamp(sx - tw / 2.0, 2, w - tw - 2);
            int ty = (int) Mth.clamp(sY + 7, 2, h - 12);
            g.fill(tx - 2, ty - 1, tx + tw + 2, ty + 9, 0x90000000);
            g.drawString(mc.font, text, tx, ty, color);
        }
    }
}
