package com.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

public class Module {
    public final String name;
    public final String description;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();
    public boolean favorite;
    private boolean enabled;

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected Setting add(Setting s) {
        settings.add(s);
        return s;
    }

    public boolean hasSettings() {
        return !settings.isEmpty();
    }

    public Setting setting(String settingName) {
        for (Setting s : settings) {
            if (s.name.equals(settingName)) return s;
        }
        throw new IllegalArgumentException("Ayar yok: " + settingName);
    }

    public boolean bool(String settingName) {
        return setting(settingName).asBool();
    }

    public int num(String settingName) {
        return setting(settingName).value;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean value) {
        if (this.enabled == value) return;
        this.enabled = value;
        if (value) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick(Minecraft client) {}
    public void onPreTick(Minecraft client) {}
    public void onFrame(Minecraft client) {}

    public List<String> hudLines() {
        return List.of();
    }

    public void renderHud(GuiGraphics g, Minecraft mc, float partial) {}
}
