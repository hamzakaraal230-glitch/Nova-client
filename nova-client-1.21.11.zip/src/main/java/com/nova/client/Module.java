package com.nova.client;

import net.minecraft.client.Minecraft;

import java.util.List;

public class Module {
    public final String name;
    public final String description;
    public final Category category;
    public boolean favorite;
    private boolean enabled;

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean value) {
        if (this.enabled == value) return;
        this.enabled = value;
        if (value) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick(Minecraft client) {}

    public List<String> hudLines() {
        return List.of();
    }
}
