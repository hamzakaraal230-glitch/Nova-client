package com.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BedBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.entity.TrialSpawnerBlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;

public final class ModuleManager {

    // ---------- Yardimci ----------
    static List<BlockEntity> scanBlockEntities(Minecraft mc, int radiusChunks) {
        List<BlockEntity> out = new ArrayList<>();
        ClientLevel level = mc.level;
        LocalPlayer p = mc.player;
        if (level == null || p == null) return out;
        int pcx = p.getBlockX() >> 4;
        int pcz = p.getBlockZ() >> 4;
        for (int dx = -radiusChunks; dx <= radiusChunks; dx++) {
            for (int dz = -radiusChunks; dz <= radiusChunks; dz++) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(pcx + dx, pcz + dz);
                if (chunk == null) continue;
                out.addAll(chunk.getBlockEntities().values());
            }
        }
        return out;
    }

    static String storageName(BlockEntity be) {
        if (be instanceof EnderChestBlockEntity) return "Ender Chest";
        if (be instanceof ShulkerBoxBlockEntity) return "Shulker";
        if (be instanceof BarrelBlockEntity) return "Barrel";
        if (be instanceof DispenserBlockEntity) return "Dispenser";
        if (be instanceof ChestBlockEntity) return "Chest";
        return null;
    }

    static String spawnerName(BlockEntity be) {
        if (be instanceof TrialSpawnerBlockEntity) return "Trial Spawner";
        if (be instanceof SpawnerBlockEntity) return "Spawner";
        return null;
    }

    static boolean isBaseBlock(BlockEntity be) {
        return storageName(be) != null
                || be instanceof AbstractFurnaceBlockEntity
                || be instanceof HopperBlockEntity
                || be instanceof BedBlockEntity;
    }

    static double distTo(LocalPlayer p, BlockPos pos) {
        double dx = pos.getX() + 0.5 - p.getX();
        double dy = pos.getY() + 0.5 - p.getY();
        double dz = pos.getZ() + 0.5 - p.getZ();
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // ---------- Modul siniflari ----------
    private record Target(double x, double y, double z, String label) {}

    public static class FinderModule extends Module {
        private final String title;
        private final int color;
        private final Predicate<BlockEntity> filter;
        private final Function<BlockEntity, String> label;
        private List<Target> targets = List.of();
        private int total;
        private int tick;

        public FinderModule(String name, String desc, String title, int defRange, int color,
                            Predicate<BlockEntity> filter, Function<BlockEntity, String> label) {
            super(name, desc, Category.RENDER);
            this.title = title;
            this.color = color;
            this.filter = filter;
            this.label = label;
            add(Setting.integer("Range (chunks)", defRange, 2, 16, 2));
            add(Setting.integer("Max targets", 8, 1, 20, 1));
        }

        @Override
        protected void onDisable() {
            targets = List.of();
            total = 0;
            tick = 0;
        }

        @Override
        public void onTick(Minecraft client) {
            if (tick++ % 20 != 0) return;
            LocalPlayer p = client.player;
            if (p == null) return;

            List<BlockEntity> found = new ArrayList<>();
            for (BlockEntity be : scanBlockEntities(client, num("Range (chunks)"))) {
                if (filter.test(be)) found.add(be);
            }
            found.sort((a, b) -> Double.compare(distTo(p, a.getBlockPos()), distTo(p, b.getBlockPos())));

            List<Target> out = new ArrayList<>();
            for (int i = 0; i < Math.min(num("Max targets"), found.size()); i++) {
                BlockEntity be = found.get(i);
                BlockPos pos = be.getBlockPos();
                out.add(new Target(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, label.apply(be)));
            }
            total = found.size();
            targets = out;
        }

        @Override
        public List<String> hudLines() {
            return List.of(title + ": " + total);
        }

        @Override
        public void renderHud(GuiGraphics g, Minecraft mc, float partial) {
            for (Target t : targets) {
                Overlay.marker(g, mc, partial, t.x(), t.y(), t.z(), t.label(), color);
            }
        }
    }

    public static class BaseFinderModule extends Module {
        private List<Target> targets = List.of();
        private int total;
        private int tick;

        public BaseFinderModule() {
            super("Base Finder", "Olası base konumları", Category.RENDER);
            add(Setting.integer("Min blocks", 4, 2, 12, 1));
            add(Setting.integer("Range (chunks)", 12, 4, 16, 2));
        }

        @Override
        protected void onDisable() {
            targets = List.of();
            total = 0;
            tick = 0;
        }

        @Override
        public void onTick(Minecraft client) {
            if (tick++ % 40 != 0) return;
            LocalPlayer p = client.player;
            if (p == null) return;

            Map<Long, int[]> counts = new HashMap<>();
            for (BlockEntity be : scanBlockEntities(client, num("Range (chunks)"))) {
                if (!isBaseBlock(be)) continue;
                BlockPos pos = be.getBlockPos();
                long key = (((long) (pos.getX() >> 4)) << 32) | ((pos.getZ() >> 4) & 0xFFFFFFFFL);
                int[] v = counts.computeIfAbsent(key, k -> new int[2]);
                v[0]++;
                v[1] += pos.getY();
            }

            List<double[]> cands = new ArrayList<>();
            for (Map.Entry<Long, int[]> e : counts.entrySet()) {
                if (e.getValue()[0] < num("Min blocks")) continue;
                int cx = (int) (e.getKey() >> 32);
                int cz = (int) (long) e.getKey();
                double wx = cx * 16.0 + 8, wz = cz * 16.0 + 8;
                double wy = (double) e.getValue()[1] / e.getValue()[0];
                double dist = Math.sqrt(Math.pow(wx - p.getX(), 2) + Math.pow(wz - p.getZ(), 2));
                cands.add(new double[]{wx, wy, wz, dist, e.getValue()[0]});
            }
            cands.sort((a, b) -> Double.compare(a[3], b[3]));

            List<Target> out = new ArrayList<>();
            for (int i = 0; i < Math.min(5, cands.size()); i++) {
                double[] c = cands.get(i);
                out.add(new Target(c[0], c[1], c[2], "Base? (" + (int) c[4] + ")"));
            }
            total = cands.size();
            targets = out;
        }

        @Override
        public List<String> hudLines() {
            return List.of("Olası base: " + total);
        }

        @Override
        public void renderHud(GuiGraphics g, Minecraft mc, float partial) {
            for (Target t : targets) {
                Overlay.marker(g, mc, partial, t.x(), t.y(), t.z(), t.label(), 0xFF3DDCFF);
            }
        }
    }

    public static class EspModule extends Module {
        private final Set<Integer> glowing = new HashSet<>();

        public EspModule() {
            super("ESP", "Oyuncuları duvar arkasından parlatır", Category.RENDER);
            add(Setting.bool("Mobs", false));
            add(Setting.integer("Range", 64, 16, 128, 16));
        }

        @Override
        public void onTick(Minecraft c) {
            if (c.level == null || c.player == null) return;
            boolean mobs = bool("Mobs");
            AABB box = c.player.getBoundingBox().inflate(num("Range"));
            List<Entity> list = c.level.getEntities((Entity) null, box,
                    e -> e instanceof LivingEntity && e != c.player);

            Set<Integer> wanted = new HashSet<>();
            for (Entity e : list) {
                if (e instanceof Player || mobs) {
                    e.setGlowingTag(true);
                    wanted.add(e.getId());
                }
            }
            glowing.addAll(wanted);

            List<Integer> drop = new ArrayList<>();
            for (int id : glowing) {
                if (wanted.contains(id)) continue;
                Entity e = c.level.getEntity(id);
                if (e != null) e.setGlowingTag(false);
                drop.add(id);
            }
            glowing.removeAll(drop);
        }

        @Override
        protected void onDisable() {
            Minecraft c = Minecraft.getInstance();
            if (c.level != null) {
                for (int id : glowing) {
                    Entity e = c.level.getEntity(id);
                    if (e != null) e.setGlowingTag(false);
                }
            }
            glowing.clear();
        }
    }

    private record OreTarget(double x, double y, double z, String label, int color) {}

    /** Cevherleri duvar arkasindan isaretler (blok gorunumunu degistirmez, 2D isaret cizer). */
    public static class XrayModule extends Module {
        private List<OreTarget> targets = List.of();
        private int total;
        private int tick;

        public XrayModule() {
            super("X-Ray", "Cevherleri duvar arkasından işaretler", Category.RENDER);
            add(Setting.integer("Range", 16, 8, 32, 4));
            add(Setting.integer("Max targets", 12, 3, 30, 3));
            add(Setting.bool("Diamond", true));
            add(Setting.bool("Debris", true));
            add(Setting.bool("Gold", false));
            add(Setting.bool("Iron", false));
        }

        @Override
        protected void onDisable() {
            targets = List.of();
            total = 0;
            tick = 0;
        }

        private int type(BlockState s) {
            if (bool("Diamond") && s.is(BlockTags.DIAMOND_ORES)) return 1;
            if (bool("Debris") && s.is(Blocks.ANCIENT_DEBRIS)) return 2;
            if (bool("Gold") && s.is(BlockTags.GOLD_ORES)) return 3;
            if (bool("Iron") && s.is(BlockTags.IRON_ORES)) return 4;
            return 0;
        }

        @Override
        public void onTick(Minecraft client) {
            if (tick++ % 20 != 0) return;
            ClientLevel level = client.level;
            LocalPlayer p = client.player;
            if (level == null || p == null) return;

            int r = num("Range");
            int px = p.getBlockX(), py = p.getBlockY(), pz = p.getBlockZ();
            int y1 = Math.max(-64, py - r), y2 = Math.min(319, py + r);
            BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();

            List<double[]> found = new ArrayList<>();
            for (int x = px - r; x <= px + r; x++) {
                for (int z = pz - r; z <= pz + r; z++) {
                    for (int y = y1; y <= y2; y++) {
                        m.set(x, y, z);
                        int t = type(level.getBlockState(m));
                        if (t == 0) continue;
                        double dx = x + 0.5 - p.getX(), dy = y + 0.5 - p.getY(), dz = z + 0.5 - p.getZ();
                        found.add(new double[]{x + 0.5, y + 0.5, z + 0.5, dx * dx + dy * dy + dz * dz, t});
                    }
                }
            }
            found.sort((a, b) -> Double.compare(a[3], b[3]));

            List<OreTarget> out = new ArrayList<>();
            for (int i = 0; i < Math.min(num("Max targets"), found.size()); i++) {
                double[] f = found.get(i);
                String name;
                int color;
                switch ((int) f[4]) {
                    case 1 -> { name = "Diamond"; color = 0xFF4DEBFF; }
                    case 2 -> { name = "Debris"; color = 0xFFFF9F43; }
                    case 3 -> { name = "Gold"; color = 0xFFFFD54A; }
                    default -> { name = "Iron"; color = 0xFFE8D5C4; }
                }
                out.add(new OreTarget(f[0], f[1], f[2], name, color));
            }
            total = found.size();
            targets = out;
        }

        @Override
        public List<String> hudLines() {
            return List.of("Ore: " + total);
        }

        @Override
        public void renderHud(GuiGraphics g, Minecraft mc, float partial) {
            for (OreTarget t : targets) {
                Overlay.marker(g, mc, partial, t.x(), t.y(), t.z(), t.label(), t.color());
            }
        }
    }

    /** Kamerayi oyuncudan ayirir; oyuncu yerinde durur, sen serbest gezersin. */
    public static class FreecamModule extends Module {
        private RemotePlayer cam;
        private double cx, cy, cz;
        private float savedYaw, savedPitch;

        public FreecamModule() {
            super("Freecam", "Kamerayı oyuncudan ayırıp serbest gez", Category.RENDER);
            add(Setting.integer("Speed", 4, 1, 10, 1));
        }

        @Override
        protected void onEnable() {
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            ClientLevel lv = mc.level;
            if (p == null || lv == null) {
                setEnabled(false);
                return;
            }
            cam = new RemotePlayer(lv, p.getGameProfile());
            cx = p.getX();
            cy = p.getY();
            cz = p.getZ();
            cam.setPos(cx, cy, cz);
            cam.setYRot(p.getYRot());
            cam.setXRot(p.getXRot());
            cam.setOldPosAndRot();
            savedYaw = p.getYRot();
            savedPitch = p.getXRot();
            mc.setCameraEntity(cam);
        }

        @Override
        protected void onDisable() {
            if (cam == null) return;
            cam = null;
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            if (p != null) {
                mc.setCameraEntity(p);
                p.setYRot(savedYaw);
                p.setXRot(savedPitch);
            }
        }

        private static boolean down(long window, int key) {
            return window != 0L && GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
        }

        @Override
        public void onPreTick(Minecraft mc) {
            LocalPlayer p = mc.player;
            if (cam == null) return;
            if (p == null || mc.level == null || mc.getCameraEntity() != cam) {
                cam = null;
                setEnabled(false);
                return;
            }

            long w = GLFW.glfwGetCurrentContext();
            boolean fwd = down(w, GLFW.GLFW_KEY_W), back = down(w, GLFW.GLFW_KEY_S);
            boolean left = down(w, GLFW.GLFW_KEY_A), right = down(w, GLFW.GLFW_KEY_D);
            boolean up = down(w, GLFW.GLFW_KEY_SPACE), dn = down(w, GLFW.GLFW_KEY_LEFT_SHIFT);

            // gercek oyuncu yerinde dursun
            mc.options.keyUp.setDown(false);
            mc.options.keyDown.setDown(false);
            mc.options.keyLeft.setDown(false);
            mc.options.keyRight.setDown(false);
            mc.options.keyJump.setDown(false);
            mc.options.keyShift.setDown(false);
            mc.options.keySprint.setDown(false);

            if (mc.screen != null) return;

            double yaw = Math.toRadians(p.getYRot());
            double pitch = Math.toRadians(p.getXRot());
            double cyw = Math.cos(yaw), syw = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
            double fx = -syw * cp, fy = -sp, fz = cyw * cp;
            double rx = -cyw, rz = -syw;

            double f = (fwd ? 1 : 0) - (back ? 1 : 0);
            double s = (right ? 1 : 0) - (left ? 1 : 0);
            double v = (up ? 1 : 0) - (dn ? 1 : 0);

            double mx = fx * f + rx * s;
            double my = fy * f + v;
            double mz = fz * f + rz * s;
            double len = Math.sqrt(mx * mx + my * my + mz * mz);
            double speed = num("Speed") * 0.15;
            if (len > 1e-6) {
                cx += mx / len * speed;
                cy += my / len * speed;
                cz += mz / len * speed;
            }
            cam.setOldPosAndRot();
            cam.setPos(cx, cy, cz);
        }

        @Override
        public void onFrame(Minecraft mc) {
            LocalPlayer p = mc.player;
            if (cam == null || p == null) return;
            cam.setYRot(p.getYRot());
            cam.setXRot(p.getXRot());
            cam.yRotO = p.getYRot();
            cam.xRotO = p.getXRot();
        }
    }

    public static class CpsModule extends Module {
        private final ArrayDeque<Long> clicks = new ArrayDeque<>();
        private boolean wasDown;

        public CpsModule() {
            super("CPS Counter", "Saniyedeki tıklama sayısı", Category.PVP);
        }

        @Override
        public void onTick(Minecraft client) {
            boolean down = client.screen == null && client.options.keyAttack.isDown();
            if (down && !wasDown) clicks.addLast(System.currentTimeMillis());
            wasDown = down;
            prune();
        }

        private void prune() {
            long limit = System.currentTimeMillis() - 1000L;
            while (!clicks.isEmpty() && clicks.peekFirst() < limit) clicks.pollFirst();
        }

        public int getCps() {
            prune();
            return clicks.size();
        }
    }

    // ---------- Moduller ----------
    public static final Module HUD = new Module("Info HUD", "FPS ve koordinatlar", Category.RENDER) {
        {
            add(Setting.bool("Show FPS", true));
            add(Setting.bool("Show coords", true));
            setEnabled(true);
        }
    };

    public static final Module FULLBRIGHT = new Module("Fullbright", "Karanlıkta görüş", Category.RENDER) {
        @Override
        public void onTick(Minecraft client) {
            LocalPlayer p = client.player;
            if (p == null) return;
            MobEffectInstance cur = p.getEffect(MobEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 240) {
                p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
            }
        }

        @Override
        protected void onDisable() {
            LocalPlayer p = Minecraft.getInstance().player;
            if (p != null) p.removeEffect(MobEffects.NIGHT_VISION);
        }
    };

    public static final Module ESP = new EspModule();

    public static final Module STORAGE_FINDER = new FinderModule(
            "Storage Finder", "Sandık, shulker, varil, dropper", "Storage", 8, 0xFFFFC233,
            be -> storageName(be) != null, ModuleManager::storageName);

    public static final Module SPAWNER_FINDER = new FinderModule(
            "Spawner Finder", "Monster ve trial spawner", "Spawner", 12, 0xFFFF4D6D,
            be -> spawnerName(be) != null, ModuleManager::spawnerName);

    public static final Module BASE_FINDER = new BaseFinderModule();

    public static final Module XRAY = new XrayModule();

    public static final Module FREECAM = new FreecamModule();

    public static final CpsModule CPS = new CpsModule();

    public static final Module KEYSTROKES = new Module("Keystrokes", "W A S D tuş gösterimi", Category.PVP);

    public static final Module SPRINT = new Module("Auto Sprint", "İleri giderken otomatik koşar", Category.MOVEMENT) {
        @Override
        public void onTick(Minecraft client) {
            LocalPlayer p = client.player;
            if (p == null) return;
            if (client.options.keyUp.isDown() && !p.isShiftKeyDown() && !p.horizontalCollision) {
                p.setSprinting(true);
            }
        }
    };

    private static final List<Module> MODULES = List.of(
            HUD, FULLBRIGHT, ESP, XRAY, FREECAM, STORAGE_FINDER, SPAWNER_FINDER, BASE_FINDER, CPS, KEYSTROKES, SPRINT);

    private ModuleManager() {}

    public static List<Module> all() {
        return MODULES;
    }

    public static List<Module> of(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) {
            if (m.category == category) out.add(m);
        }
        return out;
    }

    public static int activeCount() {
        int n = 0;
        for (Module m : MODULES) if (m.isEnabled()) n++;
        return n;
    }

    public static void preTick(Minecraft client) {
        for (Module m : MODULES) {
            if (m.isEnabled()) m.onPreTick(client);
        }
    }

    public static void frame(Minecraft client) {
        for (Module m : MODULES) {
            if (m.isEnabled()) m.onFrame(client);
        }
    }

    public static void tick(Minecraft client) {
        for (Module m : MODULES) {
            if (m.isEnabled()) m.onTick(client);
        }
    }
}
