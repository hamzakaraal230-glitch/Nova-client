package com.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BedBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.entity.TrialSpawnerBlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;

public final class ModuleManager {

    // ---------- Yardimci ----------
    static List<BlockEntity> scanBlockEntities(Minecraft mc, int radiusChunks) {
        List<BlockEntity> out = new ArrayList<>();
        ClientLevel level = mc.level;
        LocalPlayer p = mc.player;
        if (level == null || p == null) return out;
        int pcx = p.getBlockX() >> 4;
        int pcz = p.getBlockZ() >> 4;
        for (int dx = -radiusChunks; dx <= radiusChunks; dx++) {
            for (int dz = -radiusChunks; dz <= radiusChunks; dz++) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(pcx + dx, pcz + dz);
                if (chunk == null) continue;
                out.addAll(chunk.getBlockEntities().values());
            }
        }
        return out;
    }

    static String storageName(BlockEntity be) {
        if (be instanceof EnderChestBlockEntity) return "Ender Chest";
        if (be instanceof ShulkerBoxBlockEntity) return "Shulker";
        if (be instanceof BarrelBlockEntity) return "Barrel";
        if (be instanceof DispenserBlockEntity) return "Dispenser/Dropper";
        if (be instanceof ChestBlockEntity) return "Chest";
        return null;
    }

    static String spawnerName(BlockEntity be) {
        if (be instanceof TrialSpawnerBlockEntity) return "Trial Spawner";
        if (be instanceof SpawnerBlockEntity) return "Spawner";
        return null;
    }

    static boolean isBaseBlock(BlockEntity be) {
        return storageName(be) != null
                || be instanceof AbstractFurnaceBlockEntity
                || be instanceof HopperBlockEntity
                || be instanceof BedBlockEntity;
    }

    static double distTo(LocalPlayer p, BlockPos pos) {
        double dx = pos.getX() + 0.5 - p.getX();
        double dy = pos.getY() + 0.5 - p.getY();
        double dz = pos.getZ() + 0.5 - p.getZ();
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // ---------- Modul siniflari ----------
    public static class FinderModule extends Module {
        private final String title;
        private final Predicate<BlockEntity> filter;
        private final Function<BlockEntity, String> label;
        private final int radius;
        private List<String> lines = List.of();
        private int tick;

        public FinderModule(String name, String desc, String title, int radius,
                            Predicate<BlockEntity> filter, Function<BlockEntity, String> label) {
            super(name, desc, Category.RENDER);
            this.title = title;
            this.radius = radius;
            this.filter = filter;
            this.label = label;
        }

        @Override
        protected void onDisable() {
            lines = List.of();
            tick = 0;
        }

        @Override
        public void onTick(Minecraft client) {
            if (tick++ % 20 != 0) return;
            LocalPlayer p = client.player;
            if (p == null) return;

            List<BlockEntity> found = new ArrayList<>();
            for (BlockEntity be : scanBlockEntities(client, radius)) {
                if (filter.test(be)) found.add(be);
            }
            found.sort((a, b) -> Double.compare(distTo(p, a.getBlockPos()), distTo(p, b.getBlockPos())));

            List<String> out = new ArrayList<>();
            out.add(title + ": " + found.size());
            for (int i = 0; i < Math.min(5, found.size()); i++) {
                BlockEntity be = found.get(i);
                BlockPos pos = be.getBlockPos();
                out.add(label.apply(be) + "  " + (int) distTo(p, pos) + "m  ("
                        + pos.getX() + ", " + pos.getY() + ", " + pos.getZ() + ")");
            }
            lines = out;
        }

        @Override
        public List<String> hudLines() {
            return lines;
        }
    }

    public static class BaseFinderModule extends Module {
        private List<String> lines = List.of();
        private int tick;

        public BaseFinderModule() {
            super("Base Finder", "Olası base konumları", Category.RENDER);
        }

        @Override
        protected void onDisable() {
            lines = List.of();
            tick = 0;
        }

        @Override
        public void onTick(Minecraft client) {
            if (tick++ % 40 != 0) return;
            LocalPlayer p = client.player;
            if (p == null) return;

            Map<Long, Integer> counts = new HashMap<>();
            for (BlockEntity be : scanBlockEntities(client, 12)) {
                if (!isBaseBlock(be)) continue;
                BlockPos pos = be.getBlockPos();
                long key = (((long) (pos.getX() >> 4)) << 32) | ((pos.getZ() >> 4) & 0xFFFFFFFFL);
                counts.merge(key, 1, Integer::sum);
            }

            List<long[]> cands = new ArrayList<>();
            for (Map.Entry<Long, Integer> e : counts.entrySet()) {
                if (e.getValue() < 4) continue;
                int cx = (int) (e.getKey() >> 32);
                int cz = (int) (long) e.getKey();
                long worldX = cx * 16L + 8;
                long worldZ = cz * 16L + 8;
                long dist = (long) Math.sqrt(Math.pow(worldX - p.getX(), 2) + Math.pow(worldZ - p.getZ(), 2));
                cands.add(new long[]{worldX, worldZ, e.getValue(), dist});
            }
            cands.sort((a, b) -> Long.compare(a[3], b[3]));

            List<String> out = new ArrayList<>();
            out.add("Olası base: " + cands.size());
            for (int i = 0; i < Math.min(3, cands.size()); i++) {
                long[] c = cands.get(i);
                out.add("x " + c[0] + "  z " + c[1] + "  (" + c[2] + " blok, " + c[3] + "m)");
            }
            lines = out;
        }

        @Override
        public List<String> hudLines() {
            return lines;
        }
    }

    public static class EspModule extends Module {
        public EspModule() {
            super("ESP", "Oyuncu ve mobları duvar arkasından parlatır", Category.RENDER);
        }

        @Override
        public void onTick(Minecraft client) {
            apply(client, true);
        }

        @Override
        protected void onDisable() {
            apply(Minecraft.getInstance(), false);
        }

        private void apply(Minecraft c, boolean glow) {
            if (c.level == null || c.player == null) return;
            AABB box = c.player.getBoundingBox().inflate(64.0);
            List<Entity> list = c.level.getEntities((Entity) null, box,
                    e -> e instanceof LivingEntity && e != c.player);
            for (Entity e : list) {
                e.setGlowingTag(glow);
            }
        }
    }

    public static class CpsModule extends Module {
        private final ArrayDeque<Long> clicks = new ArrayDeque<>();
        private boolean wasDown;

        public CpsModule() {
            super("CPS Counter", "Saniyedeki tıklama sayısı", Category.PVP);
        }

        @Override
        public void onTick(Minecraft client) {
            boolean down = client.screen == null && client.options.keyAttack.isDown();
            if (down && !wasDown) clicks.addLast(System.currentTimeMillis());
            wasDown = down;
            prune();
        }

        private void prune() {
            long limit = System.currentTimeMillis() - 1000L;
            while (!clicks.isEmpty() && clicks.peekFirst() < limit) clicks.pollFirst();
        }

        public int getCps() {
            prune();
            return clicks.size();
        }
    }

    // ---------- Moduller ----------
    public static final Module HUD = new Module("Info HUD", "FPS ve koordinatlar", Category.RENDER) {
        { setEnabled(true); }
    };

    public static final Module FULLBRIGHT = new Module("Fullbright", "Karanlıkta görüş", Category.RENDER) {
        @Override
        public void onTick(Minecraft client) {
            LocalPlayer p = client.player;
            if (p == null) return;
            MobEffectInstance cur = p.getEffect(MobEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 240) {
                p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
            }
        }

        @Override
        protected void onDisable() {
            LocalPlayer p = Minecraft.getInstance().player;
            if (p != null) p.removeEffect(MobEffects.NIGHT_VISION);
        }
    };

    public static final Module ESP = new EspModule();

    public static final Module STORAGE_FINDER = new FinderModule(
            "Storage Finder", "Sandık, shulker, varil, dropper", "Storage", 8,
            be -> storageName(be) != null, ModuleManager::storageName);

    public static final Module SPAWNER_FINDER = new FinderModule(
            "Spawner Finder", "Monster ve trial spawner", "Spawner", 12,
            be -> spawnerName(be) != null, ModuleManager::spawnerName);

    public static final Module BASE_FINDER = new BaseFinderModule();

    public static final CpsModule CPS = new CpsModule();

    public static final Module KEYSTROKES = new Module("Keystrokes", "W A S D tuş gösterimi", Category.PVP);

    public static final Module SPRINT = new Module("Auto Sprint", "İleri giderken otomatik koşar", Category.MOVEMENT) {
        @Override
        public void onTick(Minecraft client) {
            LocalPlayer p = client.player;
            if (p == null) return;
            if (client.options.keyUp.isDown() && !p.isShiftKeyDown() && !p.horizontalCollision) {
                p.setSprinting(true);
            }
        }
    };

    private static final List<Module> MODULES = List.of(
            HUD, FULLBRIGHT, ESP, STORAGE_FINDER, SPAWNER_FINDER, BASE_FINDER, CPS, KEYSTROKES, SPRINT);

    private ModuleManager() {}

    public static List<Module> all() {
        return MODULES;
    }

    public static List<Module> of(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) {
            if (m.category == category) out.add(m);
        }
        return out;
    }

    public static int activeCount() {
        int n = 0;
        for (Module m : MODULES) if (m.isEnabled()) n++;
        return n;
    }

    public static void tick(Minecraft client) {
        for (Module m : MODULES) {
            if (m.isEnabled()) m.onTick(client);
        }
    }
}
