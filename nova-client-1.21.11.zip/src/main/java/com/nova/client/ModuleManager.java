package com.nova.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {

    public static class CpsModule extends Module {
        private final ArrayDeque<Long> clicks = new ArrayDeque<>();
        private boolean wasDown;

        public CpsModule() {
            super("CPS Counter", "Saniyedeki tiklama sayisi", Category.PVP);
        }

        @Override
        public void onTick(Minecraft client) {
            boolean down = client.screen == null && client.options.keyAttack.isDown();
            if (down && !wasDown) clicks.addLast(System.currentTimeMillis());
            wasDown = down;
            prune();
        }

        private void prune() {
            long limit = System.currentTimeMillis() - 1000L;
            while (!clicks.isEmpty() && clicks.peekFirst() < limit) clicks.pollFirst();
        }

        public int getCps() {
            prune();
            return clicks.size();
        }
    }

    public static final Module FULLBRIGHT = new Module("Fullbright", "Karanlikta gorus", Category.RENDER) {
        @Override
        public void onTick(Minecraft client) {
            LocalPlayer p = client.player;
            if (p == null) return;
            MobEffectInstance cur = p.getEffect(MobEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 240) {
                p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
            }
        }

        @Override
        protected void onDisable() {
            LocalPlayer p = Minecraft.getInstance().player;
            if (p != null) p.removeEffect(MobEffects.NIGHT_VISION);
        }
    };

    public static final Module HUD = new Module("Info HUD", "FPS ve koordinatlar", Category.RENDER) {
        { setEnabled(true); }
    };

    public static final CpsModule CPS = new CpsModule();

    public static final Module KEYSTROKES = new Module("Keystrokes", "W A S D tus gosterimi", Category.PVP);

    public static final Module SPRINT = new Module("Auto Sprint", "Ileri giderken otomatik kosar", Category.MOVEMENT) {
        @Override
        public void onTick(Minecraft client) {
            LocalPlayer p = client.player;
            if (p == null) return;
            if (client.options.keyUp.isDown() && !p.isShiftKeyDown() && !p.horizontalCollision) {
                p.setSprinting(true);
            }
        }
    };

    private static final List<Module> MODULES = List.of(HUD, FULLBRIGHT, CPS, KEYSTROKES, SPRINT);

    private ModuleManager() {}

    public static List<Module> all() {
        return MODULES;
    }

    public static List<Module> of(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) {
            if (m.category == category) out.add(m);
        }
        return out;
    }

    public static void tick(Minecraft client) {
        for (Module m : MODULES) {
            if (m.isEnabled()) m.onTick(client);
        }
    }
}
