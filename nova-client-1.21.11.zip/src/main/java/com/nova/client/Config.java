package com.nova.client;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("novaclient.properties");
    }

    private static String key(Module m) {
        return m.name.replace(' ', '_');
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        for (Module m : ModuleManager.all()) {
            String en = p.getProperty(key(m) + ".enabled");
            if (en != null) m.setEnabled(Boolean.parseBoolean(en));
            m.favorite = Boolean.parseBoolean(p.getProperty(key(m) + ".fav", "false"));
        }
        try {
            Theme.setIndex(Integer.parseInt(p.getProperty("accent", "0")));
        } catch (NumberFormatException ignored) {
        }
    }

    public static void save() {
        Properties p = new Properties();
        for (Module m : ModuleManager.all()) {
            p.setProperty(key(m) + ".enabled", String.valueOf(m.isEnabled()));
            p.setProperty(key(m) + ".fav", String.valueOf(m.favorite));
        }
        p.setProperty("accent", String.valueOf(Theme.index()));
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "NOVA CLIENT");
        } catch (IOException ignored) {
        }
    }
}
