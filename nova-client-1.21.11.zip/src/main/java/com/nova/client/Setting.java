package com.nova.client;

public class Setting {
    public enum Type { BOOL, INT }

    public final String name;
    public final Type type;
    public final int min, max, step;
    public int value;

    private Setting(String name, Type type, int value, int min, int max, int step) {
        this.name = name;
        this.type = type;
        this.value = value;
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public static Setting bool(String name, boolean def) {
        return new Setting(name, Type.BOOL, def ? 1 : 0, 0, 1, 1);
    }

    public static Setting integer(String name, int def, int min, int max, int step) {
        return new Setting(name, Type.INT, def, min, max, step);
    }

    public boolean asBool() { return value != 0; }

    public void toggle() { value = value == 0 ? 1 : 0; }

    public void inc() { value = Math.min(max, value + step); }

    public void dec() { value = Math.max(min, value - step); }

    public String display() {
        return type == Type.BOOL ? (asBool() ? "ON" : "OFF") : String.valueOf(value);
    }
}
