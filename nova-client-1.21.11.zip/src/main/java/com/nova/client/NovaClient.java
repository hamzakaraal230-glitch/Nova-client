package com.nova.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class NovaClient implements ClientModInitializer {
    public static final String MOD_ID = "novaclient";

    private static KeyMapping openGuiKey;

    private static long fpsWindowStart = System.nanoTime();
    private static int fpsFrames = 0;
    private static int fps = 0;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "main"));

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.novaclient.open_gui",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category));

        Config.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new NovaScreen());
                }
            }
            ModuleManager.tick(client);
        });

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "hud"),
                NovaClient::renderHud);
    }

    private static void renderHud(GuiGraphics g, DeltaTracker tracker) {
        Minecraft mc = Minecraft.getInstance();

        fpsFrames++;
        long now = System.nanoTime();
        if (now - fpsWindowStart >= 1_000_000_000L) {
            fps = fpsFrames;
            fpsFrames = 0;
            fpsWindowStart = now;
        }

        if (mc.player == null || mc.options.hideGui) return;

        int y = 4;
        if (ModuleManager.HUD.isEnabled()) {
            g.drawString(mc.font, "NOVA CLIENT", 4, y, Theme.accent());
            g.drawString(mc.font, "FPS: " + fps, 4, y + 11, 0xFFFFFFFF);
            g.drawString(mc.font,
                    String.format("XYZ: %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()),
                    4, y + 22, 0xFFFFFFFF);
            y += 36;
        }
        if (ModuleManager.CPS.isEnabled()) {
            g.drawString(mc.font, "CPS: " + ModuleManager.CPS.getCps(), 4, y, 0xFFFFFFFF);
            y += 14;
        }
        for (Module m : ModuleManager.all()) {
            if (!m.isEnabled()) continue;
            for (String line : m.hudLines()) {
                g.drawString(mc.font, line, 4, y, 0xFF9CC8FF);
                y += 10;
            }
        }
        if (ModuleManager.KEYSTROKES.isEnabled()) {
            key(g, mc, "W", 24, y, mc.options.keyUp.isDown());
            key(g, mc, "A", 4, y + 20, mc.options.keyLeft.isDown());
            key(g, mc, "S", 24, y + 20, mc.options.keyDown.isDown());
            key(g, mc, "D", 44, y + 20, mc.options.keyRight.isDown());
        }
    }

    private static void key(GuiGraphics g, Minecraft mc, String label, int x, int y, boolean down) {
        g.fill(x, y, x + 18, y + 18, down ? (Theme.accent() & 0x00FFFFFF) | 0xC0000000 : 0x90000000);
        g.drawCenteredString(mc.font, label, x + 9, y + 5, 0xFFFFFFFF);
    }
}
