package com.nova.client;

public enum Category {
    RENDER("Render"),
    PVP("PvP"),
    MOVEMENT("Movement");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
