# NOVA CLIENT

Minecraft Java Edition 1.21 için Java 21 ve Fabric ile oluşturulmuş istemci modudur.
Arayüzü Sağ Shift ile açıp kapatmayı amaçlar. Tema mor-siyah tasarımdır.

## Otomatik JAR derleme

`.github/workflows/build.yml` dosyası GitHub Actions ile otomatik derleme ayarı içerir. Proje GitHub deposuna yüklendikten veya yeni bir commit gönderildikten sonra:

1. Depoda **Actions** sekmesini açın.
2. **Build NOVA CLIENT JAR** çalıştırmasını seçin.
3. Çalıştırma yeşil tikle bittiğinde sayfanın altındaki **Artifacts** bölümünden `nova-client-1.0.0` dosyasını indirin.
4. İndirilen ZIP'in içindeki `nova-client-1.0.0.jar` dosyasını Minecraft 1.21 Fabric kurulumunun `mods` klasörüne kopyalayın.

İsterseniz Actions sekmesinden **Run workflow** ile derlemeyi elle başlatabilirsiniz. Bir derleme başarısız olursa, aynı çalıştırmanın **Build mod** adımındaki hata mesajı sorunu gösterir.

## Yerel derleme

Java 21 gereklidir.

Linux/macOS:

```sh
./gradlew clean build
```

Windows:

```bat
gradlew.bat clean build
```

Ana mod dosyası `build/libs/nova-client-1.0.0.jar` konumunda oluşturulur.

## Proje yapısı

- `build.gradle` — Fabric Loom, bağımlılıklar ve derleme ayarları
- `gradle.properties` — Minecraft, Fabric ve mod sürümleri
- `src/client/java/` — istemci Java kodu
- `src/main/resources/fabric.mod.json` — Fabric mod tanımı
- `.github/workflows/build.yml` — otomatik derleme iş akışı
