package dev.nova.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class NovaScreen extends Screen {
    private static final int PANEL_WIDTH = 300;
    private static final int NORMAL_ROW_HEIGHT = 36;
    private static final int COMPACT_ROW_HEIGHT = 28;
    private static final String[] OPTION_KEYS = {
        "setting.nova-client.dim_background",
        "setting.nova-client.purple_accent",
        "setting.nova-client.compact_layout"
    };
    private static final boolean[] ENABLED = {true, true, false};
    private static final int PURPLE = 0xFFAA57FF;
    private static final int NEUTRAL = 0xFF8F8999;

    public NovaScreen() {
    super(Text.translatable("screen.nova-client.title"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
    if (ENABLED[0]) {
        context.fill(0, 0, width, height, 0xB8000000);
    }

    int rowHeight = ENABLED[2] ? COMPACT_ROW_HEIGHT : NORMAL_ROW_HEIGHT;
    int panelHeight = 106 + OPTION_KEYS.length * rowHeight;
    int panelWidth = Math.min(PANEL_WIDTH, width - 24);
    int left = (width - panelWidth) / 2;
    int top = (height - panelHeight) / 2;
    int accent = ENABLED[1] ? PURPLE : NEUTRAL;

    context.fill(left, top, left + panelWidth, top + panelHeight, 0xFF101014);
    context.fill(left, top, left + panelWidth, top + 3, accent);
    context.fill(left, top + 54, left + panelWidth, top + 55, 0xFF302A37);
    context.drawCenteredTextWithShadow(textRenderer, title, width / 2, top + 15, 0xFFFFFFFF);
    context.drawCenteredTextWithShadow(textRenderer, Text.translatable("screen.nova-client.subtitle"),
        width / 2, top + 34, 0xFFAAA2B4);

    for (int index = 0; index < OPTION_KEYS.length; index++) {
        int rowTop = top + 65 + index * rowHeight;
        boolean hovered = mouseX >= left + 12 && mouseX <= left + panelWidth - 12
            && mouseY >= rowTop && mouseY <= rowTop + rowHeight - 3;
        context.fill(left + 12, rowTop, left + panelWidth - 12, rowTop + rowHeight - 3,
            hovered ? 0xFF292331 : 0xFF1B1A20);
        context.drawTextWithShadow(textRenderer, Text.translatable(OPTION_KEYS[index]),
            left + 22, rowTop + (rowHeight - 8) / 2, 0xFFE8E3ED);

        int toggleLeft = left + panelWidth - 56;
        int toggleTop = rowTop + (rowHeight - 16) / 2;
        context.fill(toggleLeft, toggleTop, toggleLeft + 36, toggleTop + 16,
            ENABLED[index] ? accent : 0xFF514B58);
        int knobLeft = ENABLED[index] ? toggleLeft + 20 : toggleLeft + 2;
        context.fill(knobLeft, toggleTop + 2, knobLeft + 12, toggleTop + 14, 0xFFFFFFFF);
        }

    context.drawCenteredTextWithShadow(textRenderer,
        Text.translatable("screen.nova-client.close_hint"), width / 2,
        top + panelHeight - 15, 0xFF9D91AA);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int rowHeight = ENABLED[2] ? COMPACT_ROW_HEIGHT : NORMAL_ROW_HEIGHT;
            int panelWidth = Math.min(PANEL_WIDTH, width - 24);
            int left = (width - panelWidth) / 2;
            int panelHeight = 106 + OPTION_KEYS.length * rowHeight;
            int top = (height - panelHeight) / 2;
            for (int index = 0; index < OPTION_KEYS.length; index++) {
                int rowTop = top + 65 + index * rowHeight;
                if (mouseX >= left + 12 && mouseX <= left + panelWidth - 12
                        && mouseY >= rowTop && mouseY <= rowTop + rowHeight - 3) {
                    ENABLED[index] = !ENABLED[index];
                    return true;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
